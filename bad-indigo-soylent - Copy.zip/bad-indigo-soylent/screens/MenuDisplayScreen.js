import React, { useState } from 'react';
import { View, Text, Picker, FlatList, StyleSheet } from 'react-native';

export default function MenuDisplayScreen() {
  const [course, setCourse] = useState('Starters');
  const menuItems = [
    { id: '1', name: 'Roast Pumpkin Soup', course: 'Starters', price: 85 },
    { id: '2', name: 'Parmesan Custard', course: 'Starters', price: 60 },
    { id: '3', name: ' Oxtail and Smoked Marrow', course: 'Starters', price: 90},
    { id: '1', name: 'Mixed Green Salad With A Raspberry Infused Vinaigrette', course: 'Starters', price: 50 }, 
    { id: '2', name: 'White bean puree balsamic glazed lamb chops', course: 'Mains', price: 100 },
    { id: '2', name: 'Sirloin Steak', course: 'Mains', price: 100 },
    { id: '2', name: 'Herb Roasted Chicken and Rice With Fresh Apricot', course: 'Mains', price: 90 },
    { id: '2', name: 'Salman and Cauliflower', course: 'Mains', price: 195 },
    { id: '3', name: 'Honey Yogurt Panna Cotta Blood Orange Sauce', course: 'Desserts', price: 195 },
     { id: '3', name: 'Grandmas Chocolate Cake', course: 'Desserts', price: 80 },
      { id: '3', name: 'Milk Tart', course: 'Desserts', price: 80 },
       { id: '3', name: 'Rum Ice Cream With Raspberry and Coffee', course: 'Desserts', price: 60 },
  ];

  const filteredItems = menuItems.filter(item => item.course === course);

  return (
    <View style={styles.container}>
      <Picker selectedValue={course} onValueChange={(itemValue) => setCourse(itemValue)} style={styles.input}>
        <Picker.Item label="Starters" value="Starters" />
        <Picker.Item label="Mains" value="Mains" />
        <Picker.Item label="Desserts" value="Desserts" />
      </Picker>
      <FlatList
        data={filteredItems}
        renderItem={({ item }) => <Text>{item.name} - R{item.price}</Text>}
        keyExtractor={item => item.id}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { padding: 20 },
  input: { marginBottom: 15 },
});
