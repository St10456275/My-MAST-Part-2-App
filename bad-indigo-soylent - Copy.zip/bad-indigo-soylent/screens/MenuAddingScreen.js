// MenuAddingScreen.js
import React, { useState } from 'react';
import { View, TextInput, Button, Picker, StyleSheet } from 'react-native';

const MenuAddingScreen = ({ navigation }) => {
    const [dishName, setDishName] = useState('');
    const [description, setDescription] = useState('');
    const [course, setCourse] = useState('');
    const [price, setPrice] = useState('');

    const handleAddItem = () => {
        // Logic to add item to menu
        navigation.navigate('Home');
    };

    return (
        <View style={styles.container}>
            <TextInput
                style={styles.input}
                placeholder="Dish Name"
                value={dishName}
                onChangeText={setDishName}
            />
            <TextInput
                style={styles.input}
                placeholder="Description"
                value={description}
                onChangeText={setDescription}
            />
            <Picker
                selectedValue={course}
                style={styles.picker}
                onValueChange={(itemValue) => setCourse(itemValue)}>
                <Picker.Item label="Select Course" value="" />
                <Picker.Item label="Starter" value="starter" />
                <Picker.Item label="Main" value="main" />
                <Picker.Item label="Dessert" value="dessert" />
            </Picker>
            <TextInput
                style={styles.input}
                placeholder="Price"
                value={price}
                onChangeText={setPrice}
                keyboardType="numeric"
            />
            <Button title="Add Menu Item" onPress={handleAddItem} />
        </View>
    );
};

const styles = StyleSheet.create({
    container: { flex: 1, padding: 20 },
    input: { height: 40, borderColor: 'gray', borderWidth: 1, marginBottom: 15, padding: 10 },
    picker: { height: 50, width: '100%', marginBottom: 15 },
});

export default MenuAddingScreen;
