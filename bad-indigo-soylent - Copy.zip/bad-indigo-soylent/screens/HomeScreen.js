// HomeScreen.js
import React from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';

const HomeScreen = ({ navigation }) => {
    return (
        <View style={styles.container}>
            <Text style={styles.title}>Welcome to Christoffel's Menu</Text>
            <Text style={styles.subtitle}>Total Menu Items: 12 {/* Number of items */}</Text>
            <Button title="Add Menu Item" onPress={() => navigation.navigate('MenuAdding')} />
            <Button title="View Menu" onPress={() => navigation.navigate('MenuDisplay')} />
        </View>
    );
};

const styles = StyleSheet.create({
    container: { flex: 1, justifyContent: 'center', padding: 20 },
    title: { fontSize: 24, fontWeight: 'bold' },
    subtitle: { fontSize: 18, marginVertical: 10 },
});

export default HomeScreen;
